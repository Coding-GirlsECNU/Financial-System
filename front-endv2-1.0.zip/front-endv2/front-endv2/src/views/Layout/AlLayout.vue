<template>
<div class="w-full h-full flex">
    <RouterView></RouterView>
</div>
</template>
<script setup>
import { RouterView } from 'vue-router';
</script>