<template>
 <div class="w-full h-full">
    
 </div>
 </template>
 
 <script setup>
 import {ref} from 'vue' 
</script> 
 
 <style scoped>
 
</style>