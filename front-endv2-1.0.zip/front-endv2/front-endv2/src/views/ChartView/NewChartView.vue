<template>
    <RouterView></RouterView>
</template>
<script setup>
</script>